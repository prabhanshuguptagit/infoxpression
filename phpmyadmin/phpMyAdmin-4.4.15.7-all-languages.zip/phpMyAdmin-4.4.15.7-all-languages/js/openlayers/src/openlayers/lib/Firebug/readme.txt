This directory contains the source for Firebug Lite
(http://www.getfirebug.com/lite.html).  This code is distributed with a
BSD License, Copyright (c) 2007, Parakey Inc.  See the included license.txt
for the full text of the license.

This is a patched version of the trunk from
http://fbug.googlecode.com/svn/trunk.

Revision 36 was patched to resolve the issue described here
http://code.google.com/p/fbug/issues/detail?id=85

When this issue is resolved, Firebug Lite can be used directly - no further
modifications are needed for OpenLayers.